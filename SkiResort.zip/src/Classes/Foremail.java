/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;
import javax.mail.Transport;

/**
 *
 * @author Admin
 */
public class Foremail {
    
    public static void sendmail(String recepient, String body) throws MessagingException {
        Properties prop = new Properties();
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true");
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        
        String account = "hrforkursova@gmail.com";
        String password = "nypqgwazqtiztbfm";
        
        Session ses = Session.getInstance(prop, new Authenticator() {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(account,password);
        } 
        
        });
        
        Message message = prepareMessage(ses, account, recepient, body);
        
        Transport.send(message);
        System.out.println("success");
        
    }

    private static Message prepareMessage(Session ses, String account, String recepient, String body) {
        try {
            Message message = new MimeMessage(ses);
            message.setFrom(new InternetAddress(account));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
            message.setSubject("Пристрій полагоджений, та очікує вас");
            message.setText(body);
            return message;
        } catch (Exception ex) {
            Logger.getLogger(Foremail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
