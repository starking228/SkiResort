package Classes;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;
import javax.swing.Icon;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class AddClient extends javax.swing.JFrame {

    //_________________________________________________
    private Connection con;
    PreparedStatement pst;
    String equipment = "", additionalEquipments = "";
    pbThead t1;
    int discount = 0, roomPrice = 0, fullRoomPrice, equipmentFullPrice;
    int total = 0;
    ArrayList<String> allEquipmentInfo = new ArrayList<>();
    //_________________________________________________
    public AddClient() {
        initComponents();
        setSize(780, 475);
        setTitle("Ski Resort");
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images/MainIco.png")));
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width / 2 - getWidth() / 2, size.height / 2 - getHeight() / 2);
        setResizable(false);
        try {
            con = DriverManager.getConnection("jdbc:mysql://194.44.236.9:3306/sqlkns23_1_gryu", "sqlkns23_1_gryu", "kns23_gryu");
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void progressBar() {
        jPanel1.setVisible(false);
        jPanel2.setVisible(true);
        t1 = new pbThead();
        t1.start();
    }

    private int CalculateSum() throws SQLException {
        int sum = 0;
        
        //equipments
        if (equipment.length() > 0) {
            sum += getEquipmentPrice(equipment);
        }
        if (additionalEquipments.length() > 0) {
            if (additionalEquipments.contains(",")) {
                String[] idOfEqupments = additionalEquipments.split(",");
                for (String idOfEqupment : idOfEqupments) {
                    sum += getEquipmentPrice(idOfEqupment);
                }
            }
            else {
                sum += getEquipmentPrice(additionalEquipments);
            }
        }
        // price for all equipment for all days
            sum += sum * Integer.parseInt(Jdays.getText());
            equipmentFullPrice = sum;
        // hotel room
        fullRoomPrice = getPriceForRoom();
        sum += fullRoomPrice;
        return sum;
    }
    
    private int getEquipmentPrice(String id_eq) throws SQLException {
        String sql = "SELECT price, name_skiing, name_boots FROM IT_Equipment WHERE id_E = "+ id_eq;
        System.out.println("hgf  " + sql);
        pst = con.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();
        if (rs.next()) {
        String line = "Лижі: " + rs.getString("name_skiing") +
                "\tВзуття: " + rs.getString("name_boots") +
                "\tЦіна:" + rs.getInt("price");
        allEquipmentInfo.add(line);
        return rs.getInt("price");
        }
        else {
            System.out.println("rmpty");
            return 0;
        }
    }

    private int getPriceForRoom() throws SQLException {
        int minDaysForDiscount = getMinDaysForDiscount();
        int days = Integer.parseInt(Jdays.getText());
        roomPrice = getPrice(returnHotelNumber());
        if (days < minDaysForDiscount) {
            return roomPrice * days;
        }
        else {
           discount = getDiscount(days);
           return roomPrice * days - (roomPrice * days) / 100 * discount;
        }
    }

    private int getMinDaysForDiscount() throws SQLException {
        String sql = "SELECT MIN(duration_s) AS min_duration FROM IT_Subscription";
        pst = con.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();
        if (rs.next()) {
        return rs.getInt("min_duration");
        }
        else {
        return 0;
        }
    }

    private int getPrice(int HotelNumber) throws SQLException {
        String sql = "SELECT price as price FROM IT_HotelRoom WHERE room =?";
        pst = con.prepareStatement(sql);
        pst.setInt(1, HotelNumber);
        java.sql.ResultSet rs = pst.executeQuery();
        if (rs.next()) {
        return rs.getInt("price");
        }
        else {
            return 0;
        }
    }

    private int getDiscount(int days) throws SQLException {
        String sql = "SELECT percent FROM IT_Subscription WHERE "
                + "duration_s >= " + days + " AND duration_f <= " + days;
        pst = con.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();
        if (rs.next()) {
        return rs.getInt("percent");
        }
        else {
            return 0;
        }
    }

    class pbThead extends Thread {


        public pbThead() {
        }

        public void run() {
            int min = 0;
            int max = 50;

            progress.setMinimum(min);
            progress.setMaximum(max);
            progress.setValue(0);

            for (int i = min; i <= max; i++) {
                progress.setValue(i);
                try {
                    sleep(10); //500
                } catch (InterruptedException ex) {
                    Logger.getLogger(AddClient.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            jPanel1.setVisible(true);
            jPanel2.setVisible(false);

            Random random = new Random();
            boolean isOk = random.nextBoolean();
            JOptionPane.showMessageDialog(rootPane, isOk);
            if (isOk) {
                JOptionPane.showMessageDialog(rootPane, "Оплата пройшла успішно");
                try {
                    InsertIntoClient();
                    changeRoomStatus();
                    createmail();
                    dispose();
                } catch (SQLException ex) {
                    Logger.getLogger(AddClient.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Виникла помилка транзакції, спробуйте ще раз");
            }
        }

        private void changeRoomStatus() throws SQLException {
            String sql = "UPDATE  IT_HotelRoom "
                    + "SET access=0, date_start=?, duration =? WHERE room =?";
            pst = con.prepareStatement(sql);
            pst.setDate(1, Date.valueOf(LocalDate.now()));
            pst.setInt(2, Integer.parseInt(Jdays.getText()));
            pst.setInt(3, returnHotelNumber());
            pst.executeUpdate();
        }

        private void createmail() {
            String body = "\t + \t + \t Чек про оплату проживання та послуг в відпочинковому комплексі \"" + "SkiResort\"\n"
                    +"Послуги оплачено на: " + Jdays.getText() + " дні.\n"
                    + "Номер готелю: " + JCmbHotel.getSelectedItem().toString() + ".\n";
            
            if (discount !=0) {
                body += "Знижка на номер готелю становить: " + discount + "%.\n";
            }
            body += "Сумарна ціна за проживання становить: " + fullRoomPrice + " грн.\n";
            if (!allEquipmentInfo.isEmpty()) {
                body += "Спорядження:\n";
                for (String line: allEquipmentInfo) {
                    body += line + "\n"; 
                }
                body += "Сумарна ціна за спорядження становить: " + equipmentFullPrice + " грн.\n";
            }
            body += "Підсумок становить: " + total + "\n"
                    + "Дякуєм що проводите ваш відпочинок саме у нас))";
        try {
            Foremail.sendmail(Jmail.getText(), body);
        } catch (MessagingException ex) {
            JOptionPane.showMessageDialog(rootPane, "Сталась помилка при складнні чи відправлені чеку!");
        }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        JFname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Jlname = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        JPhone = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        JProf = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        JMname = new javax.swing.JTextField();
        JType = new javax.swing.JComboBox<>();
        JHeight = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        JWeight = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        JFootSize = new javax.swing.JTextField();
        Jmail = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        JMainEquip = new java.awt.Checkbox();
        btnEquip = new javax.swing.JButton();
        JaddEquip = new java.awt.Checkbox();
        jLabel13 = new javax.swing.JLabel();
        JProf1 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        JHeight1 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        JFootSize1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        JCmbHotel = new javax.swing.JComboBox<>();
        Jdays = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        JbtnSave = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        progress = new javax.swing.JProgressBar();
        jLabel18 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel3.setText("Ім'я:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 50, 30));

        JFname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JFnameKeyTyped(evt);
            }
        });
        jPanel1.add(JFname, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 40, 230, -1));

        jLabel4.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel4.setText("По батькові:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 110, 30));

        Jlname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JlnameKeyTyped(evt);
            }
        });
        jPanel1.add(Jlname, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 230, -1));

        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel6.setText("Email:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 80, 30));

        JPhone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPhoneKeyTyped(evt);
            }
        });
        jPanel1.add(JPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 230, -1));

        jLabel7.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel7.setText("Висота:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 150, 30));

        JProf.setToolTipText("");
        JProf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JProfActionPerformed(evt);
            }
        });
        jPanel1.add(JProf, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 230, -1));

        jLabel5.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel5.setText("Прізвище:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 90, 30));

        JMname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JMnameKeyTyped(evt);
            }
        });
        jPanel1.add(JMname, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 230, -1));

        JType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Дорослий", "Дитячий" }));
        JType.setToolTipText("");
        jPanel1.add(JType, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 60, 190, -1));

        JHeight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JHeightActionPerformed(evt);
            }
        });
        JHeight.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JHeightKeyTyped(evt);
            }
        });
        jPanel1.add(JHeight, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 230, -1));

        jLabel8.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel8.setText("Професіоналізм:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 140, 30));

        jLabel10.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel10.setText("Тип обладнання:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 60, 150, 30));

        jLabel11.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel11.setText("Вага:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 150, 30));

        JWeight.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JWeightKeyTyped(evt);
            }
        });
        jPanel1.add(JWeight, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 230, -1));

        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel12.setText("Кількість днів:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 150, 30));

        JFootSize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JFootSizeActionPerformed(evt);
            }
        });
        JFootSize.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JFootSizeKeyTyped(evt);
            }
        });
        jPanel1.add(JFootSize, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 230, -1));

        Jmail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JmailKeyTyped(evt);
            }
        });
        jPanel1.add(Jmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 250, 230, -1));

        jLabel9.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel9.setText("Телефон:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 80, 30));

        JMainEquip.setLabel("Особисте спорядження");
        JMainEquip.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JMainEquipMouseClicked(evt);
            }
        });
        jPanel1.add(JMainEquip, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        btnEquip.setText("Додати додаткове спорядження");
        btnEquip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEquipActionPerformed(evt);
            }
        });
        jPanel1.add(btnEquip, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 200, -1, -1));

        JaddEquip.setLabel("Додаткове спорядження");
        JaddEquip.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JaddEquipMouseClicked(evt);
            }
        });
        jPanel1.add(JaddEquip, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, -1));

        jLabel13.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel13.setText("Професіоналізм:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 140, 30));

        JProf1.setToolTipText("");
        jPanel1.add(JProf1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 90, 190, -1));

        jLabel14.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel14.setText("Висота:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 150, 30));

        JHeight1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JHeight1KeyTyped(evt);
            }
        });
        jPanel1.add(JHeight1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 120, 190, -1));

        jLabel15.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel15.setText("Розмір стопи:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 150, 150, 30));

        JFootSize1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JFootSize1KeyTyped(evt);
            }
        });
        jPanel1.add(JFootSize1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 150, 190, -1));

        jLabel2.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jLabel2.setText("Введіть дані для підбору додаткового спорядження");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, -1, -1));

        btnAdd.setText("Оплатити");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        jPanel1.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, -1, -1));

        jLabel16.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel16.setText("Розмір стопи:");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 150, 30));

        jPanel1.add(JCmbHotel, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 310, 230, -1));

        Jdays.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JdaysKeyTyped(evt);
            }
        });
        jPanel1.add(Jdays, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 340, 230, -1));

        jLabel17.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel17.setText("Номер готелю:");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 150, 30));

        JbtnSave.setText("Зберегти");
        JbtnSave.setEnabled(false);
        jPanel1.add(JbtnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 370, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/AddClient.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -10, 800, 460));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(progress, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 630, 40));

        jLabel18.setFont(new java.awt.Font("Bahnschrift", 0, 24)); // NOI18N
        jLabel18.setText("Зв'язуємся з банком, будь ласка зачекайте");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 490, 70));

        jMenu1.setText("Очистити");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 782, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 782, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 61, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 61, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 456, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 138, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 138, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        jPanel2.setVisible(false);
        JHeight1.setVisible(false);
        JFootSize1.setVisible(false);
        JType.setVisible(false);
        JProf1.setVisible(false);
        jLabel2.setVisible(false);
        jLabel10.setVisible(false);
        jLabel13.setVisible(false);
        jLabel15.setVisible(false);
        jLabel14.setVisible(false);
        btnEquip.setVisible(false);

        JCmbHotel.addItem(" ");
        JProf.addItem(" ");
        JProf1.addItem(" ");
        String query = "SELECT DISTINCT proffesional FROM IT_Equipment";
        try {
            pst = con.prepareStatement(query);
            java.sql.ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                JProf.addItem(String.valueOf(rs.getString("proffesional")));
                JProf1.addItem(String.valueOf(rs.getString("proffesional")));
            }
            JProf.removeItem("null");
            JProf1.removeItem("null");
            query = "SELECT room, type, price FROM IT_HotelRoom WHERE access = '1'";
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                JCmbHotel.addItem("№ " + String.valueOf(rs.getInt("room"))
                        + "| Місткість: " + rs.getString("type") + " Людини"
                        + "| Ціна: " + String.valueOf(rs.getInt("price")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_formWindowOpened

    private void JFnameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JFnameKeyTyped
        validationForInitials(evt);
    }//GEN-LAST:event_JFnameKeyTyped

    private void JlnameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JlnameKeyTyped
        validationForInitials(evt);
    }//GEN-LAST:event_JlnameKeyTyped

    private void JPhoneKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPhoneKeyTyped
        char k = evt.getKeyChar();
        if (!Character.isDigit(k) || JPhone.getText().length() >= 10) {
            evt.consume();
        }
    }//GEN-LAST:event_JPhoneKeyTyped

    private void JProfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JProfActionPerformed
        clearMainEquipment();
    }//GEN-LAST:event_JProfActionPerformed

    private void JMnameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JMnameKeyTyped
        validationForInitials(evt);
    }//GEN-LAST:event_JMnameKeyTyped

    private void JHeightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JHeightActionPerformed
        clearMainEquipment();
    }//GEN-LAST:event_JHeightActionPerformed

    private void JHeightKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JHeightKeyTyped
        validationForDigitData(JHeight.getText().length(), evt);
        if (JHeight.getText().length() >= 3) {
            evt.consume();
        }
    }//GEN-LAST:event_JHeightKeyTyped

    private void JWeightKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JWeightKeyTyped
        validationForDigitData(JWeight.getText().length(), evt);
        if (JWeight.getText().length() >= 3) {
            evt.consume();
        }
    }//GEN-LAST:event_JWeightKeyTyped

    private void JFootSizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JFootSizeActionPerformed
        clearMainEquipment();
    }//GEN-LAST:event_JFootSizeActionPerformed

    private void JFootSizeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JFootSizeKeyTyped
        validationForDigitData(JFootSize.getText().length(), evt);
        if (JFootSize.getText().length() >= 2) {
            evt.consume();
        }
    }//GEN-LAST:event_JFootSizeKeyTyped

    private void JmailKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JmailKeyTyped
        char c = evt.getKeyChar();
        if (Jmail.getText().contains("@") && c == '@') {
            evt.consume();
        } else if (Jmail.getText().contains(".") && c == '.') {
            evt.consume();
        } else if (!Character.isAlphabetic(c) && !Character.isDigit(c) && c != '@' && c != '.') {
            evt.consume();
        }
    }//GEN-LAST:event_JmailKeyTyped

    private void JMainEquipMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JMainEquipMouseClicked
        if (equipment.equals("")) {
            if (isFilledFor_Equip(0)) {
                String query = "SELECT id_E FROM IT_Equipment WHERE proffesional = '" + JProf.getSelectedItem()
                        + "' AND " + JHeight.getText() + " BETWEEN min_height AND max_height "
                        + "AND " + JFootSize.getText() + " BETWEEN min_foot AND max_foot";
                equipment = findEquipment(query);
                JOptionPane.showMessageDialog(rootPane, equipment);
            }
        } else {
            equipment = "";
        }
    }//GEN-LAST:event_JMainEquipMouseClicked

    private void btnEquipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEquipActionPerformed
        if (isFilledFor_Equip(1)) {
            String query = (JType.getSelectedIndex() == 0)
                    ? "SELECT id_E FROM IT_Equipment WHERE proffesional = '" + JProf1.getSelectedItem()
                    : "SELECT id_E FROM IT_Equipment WHERE type = '" + JType.getSelectedItem();

            query += "' AND min_height <=" + JHeight1.getText()
                    + " AND max_height >=" + JHeight1.getText()
                    + " AND min_foot <=" + JFootSize1.getText()
                    + " AND max_foot >=" + JFootSize1.getText();
            String eq = findEquipment(query);
            if ("".equals(additionalEquipments)) {
                additionalEquipments += (eq == null) ? "" : eq;
            } else {
                additionalEquipments += (eq == null) ? "" : "," + eq;
            }
            if (eq != null) {
                btnAdd.setEnabled(true);
                JOptionPane.showMessageDialog(rootPane, "Додаткове спорядження успішно підібрано та збережено +\n"
                        + "Якщо вам потрібно ще комплект спорядження, натисність на кнопку після введення нових даних.");
            }
        }
    }//GEN-LAST:event_btnEquipActionPerformed

    private void JaddEquipMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JaddEquipMouseClicked
        if (!btnEquip.isVisible()) {
            btnAdd.setEnabled(false);
            JHeight1.setVisible(true);
            JFootSize1.setVisible(true);
            JType.setVisible(true);
            JProf1.setVisible(true);
            jLabel2.setVisible(true);
            jLabel10.setVisible(true);
            jLabel13.setVisible(true);
            jLabel15.setVisible(true);
            jLabel14.setVisible(true);
            btnEquip.setVisible(true);
        } else {
            btnAdd.setEnabled(true);
            additionalEquipments = "";
            JHeight1.setVisible(false);
            JFootSize1.setVisible(false);
            JType.setVisible(false);
            JProf1.setVisible(false);
            jLabel2.setVisible(false);
            jLabel10.setVisible(false);
            jLabel13.setVisible(false);
            jLabel15.setVisible(false);
            jLabel14.setVisible(false);
            btnEquip.setVisible(false);
        }
    }//GEN-LAST:event_JaddEquipMouseClicked

    private void JHeight1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JHeight1KeyTyped
        validationForDigitData(JHeight1.getText().length(), evt);
        if (JHeight1.getText().length() >= 3) {
            evt.consume();
        }
    }//GEN-LAST:event_JHeight1KeyTyped

    private void JFootSize1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JFootSize1KeyTyped
        validationForDigitData(JFootSize1.getText().length(), evt);
        if (JFootSize1.getText().length() >= 3) {
            evt.consume();
        }
    }//GEN-LAST:event_JFootSize1KeyTyped

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        if (isFilledFields()) {
            int sum = 0;
            try {
                sum = CalculateSum();
            } catch (SQLException ex) {
                Logger.getLogger(AddClient.class.getName()).log(Level.SEVERE, null, ex);
            }
            Icon icon = new javax.swing.ImageIcon(getClass().getResource("/images/pay_ico.png"));
            int answer = JOptionPane.showConfirmDialog(this,
                    "Загальна сума становить " + sum + " грн, підтвердити оплату?", "Підтвердження оплати",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE, icon);
            if (answer == JOptionPane.YES_OPTION) {
                total = sum;
            progressBar();
            }
        }
    }//GEN-LAST:event_btnAddActionPerformed

    private void JdaysKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JdaysKeyTyped
        validationForDigitData(Jdays.getText().length(), evt);
        if (Jdays.getText().length() >= 3) {
            evt.consume();
        }
    }//GEN-LAST:event_JdaysKeyTyped

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        JFname.setText("");
        Jlname.setText("");
        JMname.setText("");
        JProf.setSelectedIndex(0);
        JHeight.setText("");
        JHeight1.setText("");
        JProf1.setSelectedIndex(0);
        JWeight.setText("");
        JPhone.setText("");
        Jmail.setText("");
        JFootSize.setText("");
        JFootSize1.setText("");
        JCmbHotel.setSelectedIndex(0);
        Jdays.setText("");
        JMainEquip.setState(false);
        JaddEquip.setState(false);
        equipment = ""; 
        additionalEquipments = "";
        discount = 0; roomPrice = 0; fullRoomPrice = 0; equipmentFullPrice = 0;
        total = 0;
        allEquipmentInfo.clear();
    }//GEN-LAST:event_jMenu1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddClient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddClient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddClient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddClient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddClient().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> JCmbHotel;
    private javax.swing.JTextField JFname;
    private javax.swing.JTextField JFootSize;
    private javax.swing.JTextField JFootSize1;
    private javax.swing.JTextField JHeight;
    private javax.swing.JTextField JHeight1;
    private java.awt.Checkbox JMainEquip;
    private javax.swing.JTextField JMname;
    private javax.swing.JTextField JPhone;
    private javax.swing.JComboBox<String> JProf;
    private javax.swing.JComboBox<String> JProf1;
    private javax.swing.JComboBox<String> JType;
    private javax.swing.JTextField JWeight;
    private java.awt.Checkbox JaddEquip;
    private javax.swing.JButton JbtnSave;
    private javax.swing.JTextField Jdays;
    private javax.swing.JTextField Jlname;
    private javax.swing.JTextField Jmail;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnEquip;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JProgressBar progress;
    // End of variables declaration//GEN-END:variables

    private void validationForInitials(KeyEvent evt) {
        char k = evt.getKeyChar();
        int n = (int) k;
        if (!Character.isAlphabetic(k) && n != 39) {
            evt.consume();
        }
    }

    private void validationForDigitData(int length, KeyEvent evt) {
        char k = evt.getKeyChar();
        if (length == 0 && k == '0') {
            evt.consume();
        }
        if (!Character.isDigit(k)) {
            evt.consume();
        }
    }

    private boolean isFilledFor_Equip(int number) {
        boolean isCorrect = true;
        if (number == 0) {
            if (JProf.getSelectedIndex() == 0
                    || JHeight.getText().isEmpty()
                    || JFootSize.getText().isEmpty()) {
                isCorrect = false;
                JMainEquip.setState(false);
            }
        } else {
            if (JType.getSelectedIndex() == 1 && JProf1.getSelectedIndex() != 0
                    || JType.getSelectedIndex() == 0 && JProf1.getSelectedIndex() == 0
                    || JHeight1.getText().isEmpty()
                    || JFootSize1.getText().isEmpty()) {
                isCorrect = false;
            }
        }

        if (isCorrect) {
            return true;
        } else {
            JOptionPane.showMessageDialog(rootPane, "Зповніть поля вашими даними для коректного визначення спорядження",
                    "Незаповнені поля", JOptionPane.INFORMATION_MESSAGE);
            return false;
        }
    }

    private void clearMainEquipment() {
        JMainEquip.setState(false);
        equipment = "";
    }

    private boolean isFilledFields() {
        if (Jlname.getText().isEmpty()
                || JFname.getText().isEmpty()
                || JMname.getText().isEmpty()
                || JProf.getSelectedIndex() == 0
                || JHeight.getText().isEmpty()
                || JWeight.getText().isEmpty()
                || JFootSize.getText().isEmpty()
                || Jdays.getText().isEmpty()
                || JCmbHotel.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(rootPane, "Зповніть усі поля!");
            return false;
        } else {
            int days = Integer.parseInt(Jdays.getText());
            if (days < 1 || days > 365) {
                JOptionPane.showMessageDialog(rootPane, "Введіть кількість днів від 1 до 365 днів включно!");
                return false;
            }
            if (checkPhone()) {
                if (checkMail()) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean checkPhone() {
        if (JPhone.getText().length() < 10) {
            JOptionPane.showMessageDialog(rootPane, "Номер телефону повинен містити 10 чисел");
            JPhone.setFocusable(true);
            return false;
        }
        return true;
    }

    private boolean checkMail() {
        if (Jmail.getText().isEmpty()
                || !Jmail.getText().contains("@gmail.com")
                && !Jmail.getText().contains("@nltu.lviv.ua")
                || Jmail.getText().length() <= 10) {
            JOptionPane.showMessageDialog(rootPane, "Введена некоректна пошта");
            Jmail.setFocusable(true);
            return false;
        } else {
            return true;
        }
    }

    private String findEquipment(String query) {
        try {
            pst = con.prepareStatement(query);
            java.sql.ResultSet rs = pst.executeQuery();
            System.out.println(query);
            if (rs.next()) {
                return String.valueOf(rs.getString("id_E"));
            } else {
                JOptionPane.showMessageDialog(rootPane, "Підходящого спорядження не знайдено");
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private void InsertIntoClient() throws SQLException {
        String query = "insert into IT_Clients "
                + "(first_name, last_name, middle_name, professional, height, "
                + "weight, mail, number, hotel_room, equipment) values (?,?,?,?,?,?,?,?,?,?)";

        pst = con.prepareStatement(query);
        pst.setString(1, JFname.getText());
        pst.setString(2, Jlname.getText());
        pst.setString(3, JMname.getText());
        pst.setString(4, JProf.getSelectedItem().toString());
        pst.setInt(5, Integer.parseInt(JHeight.getText()));
        pst.setInt(6, Integer.parseInt(JWeight.getText()));
        pst.setString(7, Jmail.getText());
        pst.setString(8, JPhone.getText());
        pst.setInt(9, returnHotelNumber());
        pst.setString(10, getAllEquipments());

        pst.executeUpdate();
        System.out.println("success");
    }

    private String getAllEquipments() {
        if (!JMainEquip.getState() && !JaddEquip.getState()) {
            return "Немає";
        } else {
            return (JMainEquip.getState() && JaddEquip.getState()) ? equipment + "," + additionalEquipments
                    : (JMainEquip.getState()) ? equipment
                    : additionalEquipments;
        }
    }

    private int returnHotelNumber() {
        String numberInfo = JCmbHotel.getSelectedItem().toString();
        String number = "" + numberInfo.charAt(2) + numberInfo.charAt(3) + numberInfo.charAt(4);
        return Integer.parseInt(number);
    }
}
